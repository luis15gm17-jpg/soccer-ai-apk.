SOCCER AI APK — INSTRUCCIONES SENCILLAS

QUÉ INCLUYE
- Aplicación Android básica con pantalla adaptada a celular.
- Cálculo de probabilidades 1X2, doble oportunidad, más/menos goles, ambos anotan y marcadores probables.
- Estimación Poisson con los últimos cinco partidos que tú captures.
- Cálculo orientativo de cuota justa y valor teórico (EV) cuando introduces cuotas.
- El análisis funciona sin conexión después de instalar.

IMPORTANTE
Esta versión NO descarga estadísticas en vivo. Debes introducir manualmente los resultados recientes y cuotas. No incluye todavía tiros a puerta por jugador, corners, alineaciones, lesiones ni momios automáticos. Las probabilidades son estimaciones y no garantizan resultados.

CÓMO GENERAR EL APK SIN INSTALAR PROGRAMAS EN TU CELULAR
1. Entra a GitHub y abre tu repositorio soccer-ai (o crea uno nuevo).
2. Sube TODOS los archivos y carpetas de este ZIP al repositorio, respetando las carpetas.
   Si lo vas a subir al repositorio que ya tiene la versión Streamlit, puedes crear un repositorio aparte llamado soccer-ai-apk para evitar mezclar archivos.
3. En GitHub, abre la pestaña "Actions".
4. Si aparece una advertencia para habilitar Actions, habilítalo.
5. Abre el flujo "Crear APK de Soccer AI" y pulsa "Run workflow". Si ya corrió automáticamente, abre la ejecución más reciente.
6. Espera a que termine con una marca verde.
7. Abre esa ejecución, baja hasta "Artifacts" y descarga "Soccer-AI-APK".
8. Descomprime el ZIP descargado en tu celular y abre app-debug.apk para instalarlo.
9. Si Android te lo pide, autoriza temporalmente a Chrome o a la aplicación de archivos para instalar apps desconocidas. Instala solo el APK que generaste desde tu propio repositorio.

SI FALLA
Abre la ejecución en GitHub Actions y revisa el primer paso en rojo. Puedes copiar el mensaje de error y pedir ayuda.

NO ES UNA APP PUBLICADA EN PLAY STORE. Es una APK de prueba para instalar manualmente.
